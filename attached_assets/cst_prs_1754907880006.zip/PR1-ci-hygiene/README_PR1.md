# PR 1 — CI & repo-hygiëne

**Wat zit erin:**
- GitHub Actions workflow (`.github/workflows/ci.yml`) met:
  - `uv sync --frozen`
  - `ruff`, `black`, `mypy` (via `uvx`)
  - `pytest` (via `uv run` of `uvx` fallback)
  - `pip-audit` security check
- `pytest.ini` met markers en strengere defaults
- `.gitignore.suggested` en `.gitignore.additions` (merge met je bestaande `.gitignore`)

**Commit & PR aanmaken (voorbeeld):**
```bash
git checkout -b chore/ci-hygiene
mkdir -p .github/workflows
cp ./PR1-ci-hygiene/.github/workflows/ci.yml .github/workflows/ci.yml
cp ./PR1-ci-hygiene/pytest.ini ./pytest.ini
# Merge .gitignore handmatig:
#   - als je nog geen .gitignore hebt:
#       cp ./PR1-ci-hygiene/.gitignore.suggested .gitignore
#   - als je al een .gitignore hebt: open deze en plak de inhoud van .gitignore.additions erbij
git add -A
git commit -m "chore(ci): add GitHub Actions + pytest.ini + gitignore improvements"
git push -u origin HEAD
# Maak via GitHub een Pull Request naar main
```
