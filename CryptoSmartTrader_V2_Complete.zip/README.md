# CryptoSmartTrader V2

A sophisticated multi-agent cryptocurrency trading intelligence system with institutional-grade analysis capabilities.

## 🚀 Quick Start

### 1. Environment Setup
Copy the example environment file and configure your settings:
```bash
cp .env.example .env
# Edit .env with your actual configuration
```

### 2. OpenAI API Key (Optional)
For advanced sentiment analysis, add your OpenAI API key:
- Get your API key from https://platform.openai.com
- Add it to your `.env` file: `OPENAI_API_KEY=your_key_here`
- The system works without this but has limited sentiment analysis

### 3. Start the Application
The system automatically starts when you open this project. Access it at:
- **Main Dashboard:** http://localhost:5000
- **API Documentation:** http://localhost:8001/docs (when API server is running)
- **Metrics:** http://localhost:8000 (when Prometheus is enabled)

## 📊 Features

### Multi-Agent Intelligence System
- **Sentiment Agent:** Analyzes cryptocurrency news and social media
- **Technical Agent:** Calculates 50+ technical indicators
- **ML Predictor:** Machine learning price predictions (1h, 4h, 1d, 7d, 30d)
- **Backtest Agent:** Historical strategy validation  
- **Trade Executor:** Risk-managed signal generation
- **Whale Detector:** Large transaction monitoring

### Advanced Performance Features (Nieuwe Verbeteringen)
- **Performance Optimizer:** Real-time system monitoring with automatic optimization
- **Smart Error Handling:** Advanced error recovery with registered strategies  
- **Rate Limiting:** Intelligent API rate limiting with priority handling
- **Config Optimization:** Automatic configuration tuning based on performance
- **System Monitoring:** Complete performance dashboard met Nederlandse interface

### Professional Architecture
- **Dependency Injection:** Clean, testable architecture
- **Type Safety:** Full type hints and validation
- **Async Processing:** High-performance concurrent operations
- **Structured Logging:** JSON logs with rotation
- **Metrics Monitoring:** Prometheus integration
- **Input Validation:** Secure request processing

## 🎯 How to Use

### Web Dashboard
1. Navigate to the **Main Dashboard** for market overview
2. Check **Agent Dashboard** for individual agent performance  
3. Use **Portfolio Dashboard** for position tracking
4. Monitor system health in the sidebar

### REST API
Start the API server:
```bash
python api/main.py
```

Key endpoints:
- `GET /health` - System health status
- `POST /api/v1/market-data` - Get market data
- `POST /api/v1/predictions` - ML price predictions
- `POST /api/v1/signals` - Trading signals
- `GET /docs` - Interactive API documentation

### Configuration
The system uses environment variables for configuration:
- `LOG_LEVEL` - Logging level (INFO, DEBUG, ERROR)
- `ENABLE_PROMETHEUS` - Enable metrics collection
- `SENTIMENT_ANALYSIS_ENABLED` - Enable sentiment analysis
- `ML_PREDICTION_ENABLED` - Enable ML predictions

## 🧪 Testing

Run the test suite:
```bash
pytest
```

Run with coverage:
```bash
pytest --cov=./
```

## 🔧 Development

### Code Quality
Pre-commit hooks are configured for:
- Black code formatting
- isort import sorting  
- flake8 linting
- Type checking with mypy

Install pre-commit:
```bash
pre-commit install
```

### Adding New Features
1. Follow the dependency injection pattern
2. Add proper type hints
3. Write tests in the `tests/` directory
4. Update documentation

## 📈 Monitoring

### Health Checks
The system provides A-F health grading:
- **A (90-100%):** Excellent - All systems optimal
- **B (80-89%):** Good - Minor issues
- **C (70-79%):** Fair - Some performance degradation  
- **D (60-69%):** Poor - Significant issues
- **F (<60%):** Critical - Major problems

### Metrics
When Prometheus is enabled, metrics are available at `http://localhost:8000`:
- Request counts and latency
- Agent performance scores
- Data freshness indicators
- Error rates and health scores

### Logging  
Structured JSON logs are written to the `logs/` directory:
- `cryptotrader.json` - General application logs
- `errors.json` - Error-specific logs

## 🔒 Security

### Secret Management  
- Environment variables for configuration
- Optional HashiCorp Vault integration
- Input validation on all endpoints
- Sanitization to prevent injection attacks

### API Security
- CORS configuration for web integration
- Request validation with Pydantic models
- Structured error responses
- Rate limiting and timeout protection

## 🎛️ Advanced Configuration

### Vault Integration
For production secret management:
```bash
VAULT_ENABLED=true
VAULT_ADDR=https://vault.example.com
VAULT_TOKEN=your_vault_token
```

### GPU Acceleration
Enable GPU processing for ML models:
```bash
ENABLE_GPU=true
```

### Custom Agents
Extend the system by adding custom agents to the `agents/` directory following the existing patterns.

## 📋 System Requirements

- Python 3.11+
- Memory: 4GB+ recommended
- Storage: 2GB+ for data and models
- Network: Internet connection for market data

## 🆘 Troubleshooting

### Common Issues

**Import Errors:**
- Check that all dependencies are installed
- Verify Python version compatibility

**API Connection Issues:**  
- Verify your API keys are correct
- Check network connectivity
- Review logs for detailed error messages

**Performance Issues:**
- Monitor memory usage in health dashboard
- Check cache hit ratios in metrics
- Consider enabling GPU acceleration

### Support
Check the logs in the `logs/` directory for detailed error information. The health dashboard provides real-time system status and performance metrics.

---

**Version:** 2.0.0  
**Last Updated:** August 2025  
**Architecture:** Production-ready with Dutch architectural requirements implemented