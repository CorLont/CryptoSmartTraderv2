# CryptoSmartTrader — PR Bundels (1, 2, 3)

Deze map bevat drie losse "PR-bundels" die je 1-op-1 kunt toevoegen aan je repo:

- `PR1-ci-hygiene/` — GitHub Actions CI, pytest.ini en gitignore-voorstellen
- `PR2-config-hardening/` — `Settings`, logging en `__main__` entrypoint
- `PR3-api-contract/` — FastAPI app-factory, `/health`-router en test

Volg in elke map het bestand `README_PR*.md` voor de exacte copy-commando's.
