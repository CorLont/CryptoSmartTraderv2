# config/__init__.py
"""
Configuration package for CryptoSmartTrader V2.
Contains settings, logging, and configuration management.
"""