from .config import Settings
from .logging import setup_logging


def main() -> None:
    settings = Settings()
    setup_logging(settings.LOG_LEVEL)
    # Hier kun je start-logica plaatsen (API, dashboard, agents) obv toggles
    # Voor nu alleen een startmelding:
    import logging
    log = logging.getLogger(__name__)
    log.info("CryptoSmartTrader gestart met API op %s:%s (dashboard %s)", settings.API_HOST, settings.API_PORT, settings.DASH_PORT)


if __name__ == "__main__":
    main()
