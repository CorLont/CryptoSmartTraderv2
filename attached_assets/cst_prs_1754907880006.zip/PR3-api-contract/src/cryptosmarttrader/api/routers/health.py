from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(tags=["health"])


class HealthOut(BaseModel):
    status: str
    score: float


@router.get("/health", response_model=HealthOut)
async def health() -> HealthOut:
    # TODO: haal echte metrics/health-score op uit orchestrator/metrics
    return HealthOut(status="ok", score=0.97)
