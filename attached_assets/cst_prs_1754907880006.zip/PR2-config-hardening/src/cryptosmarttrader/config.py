from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    \"\\"Centrale configuratie (geladen uit env/.env) met type-validatie.\"\\"

    # Runtime
    LOG_LEVEL: str = Field("INFO", description="Logniveau: DEBUG/INFO/WARNING/ERROR")
    API_HOST: str = Field("0.0.0.0", description="Bind host voor API")
    API_PORT: int = Field(8001, description="Poort voor API")
    DASH_PORT: int = Field(5000, description="Poort voor dashboard")
    ENABLE_PROMETHEUS: bool = Field(True, description="Prometheus metrics aan/uit")

    # Extern (voorbeeld; voeg je eigen keys toe)
    OPENAI_API_KEY: str | None = None
    KRAKEN_API_KEY: str | None = None
    KRAKEN_API_SECRET: str | None = None

    model_config = {
        "env_file": ".env",
        "extra": "ignore",
    }
