# PR 2 — Config hardening (Settings + logging + entrypoint)

**Wat zit erin:**
- `src/cryptosmarttrader/config.py` — Pydantic Settings met type-validatie
- `src/cryptosmarttrader/logging.py` — uniforme logging-setup
- `src/cryptosmarttrader/__main__.py` — start-entrypoint

**Belangrijk:**
- Dit is non-intrusive: je bestaande code blijft werken. Je kunt geleidelijk code laten lezen uit `Settings()`.
- Check of je `pyproject.toml` al `pydantic` en `pydantic-settings` bevat; zo niet, voeg de snippet toe.

**Commit & PR aanmaken (voorbeeld):**
```bash
git checkout -b feat/config-hardening
mkdir -p src/cryptosmarttrader
cp -r ./PR2-config-hardening/src/cryptosmarttrader/* ./src/cryptosmarttrader/
git add -A
git commit -m "feat(config): add Settings + logging + __main__ entrypoint"
git push -u origin HEAD
# Maak een Pull Request naar main
```
