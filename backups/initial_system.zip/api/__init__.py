# api/__init__.py
"""
REST API package for CryptoSmartTrader V2.
Provides FastAPI endpoints with type hints and documentation.
"""