# PR 3 — API contract (FastAPI) + health endpoint + test

**Wat zit erin:**
- `src/cryptosmarttrader/api/app.py` met `get_app()` (FastAPI-factory)
- `src/cryptosmarttrader/api/routers/health.py` met `/health`
- `tests/api/test_health.py` end-to-end test met `httpx.AsyncClient`

**Run lokaal (voorbeeld):**
```bash
uv sync
uv run uvicorn cryptosmarttrader.api.app:get_app --factory --host 0.0.0.0 --port 8001
# Open http://localhost:8001/health
```

**Commit & PR aanmaken (voorbeeld):**
```bash
git checkout -b feat/api-contract-health
mkdir -p src/cryptosmarttrader/api/routers
mkdir -p tests/api
cp -r ./PR3-api-contract/src/cryptosmarttrader/api/* ./src/cryptosmarttrader/api/
cp -r ./PR3-api-contract/tests/api/* ./tests/api/
git add -A
git commit -m "feat(api): add FastAPI app factory + /health endpoint + test"
git push -u origin HEAD
# Maak een Pull Request naar main
```
