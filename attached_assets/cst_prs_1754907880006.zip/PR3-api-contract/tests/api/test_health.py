import pytest
from httpx import AsyncClient

from cryptosmarttrader.api.app import get_app


@pytest.mark.anyio
async def test_health_endpoint():
    app = get_app()
    async with AsyncClient(app=app, base_url="http://test") as ac:
        resp = await ac.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert set(data.keys()) >= {"status", "score"}
    assert data["status"] in {"ok", "degraded", "fail"}
