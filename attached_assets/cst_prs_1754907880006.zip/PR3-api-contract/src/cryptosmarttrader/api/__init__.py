# Package marker for cryptosmarttrader.api
