from fastapi import FastAPI
from .routers.health import router as health_router


def get_app() -> FastAPI:
    app = FastAPI(title="CryptoSmartTrader API", version="0.1.0")
    app.include_router(health_router)
    return app


# Uvicorn entrypoint: uv run uvicorn cryptosmarttrader.api.app:get_app --factory --host 0.0.0.0 --port 8001
